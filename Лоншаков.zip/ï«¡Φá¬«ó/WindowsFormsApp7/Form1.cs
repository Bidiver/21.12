﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {

        Rectangle Rectangle = new Rectangle(10, 10, 200, 100);
        Rectangle Circle = new Rectangle(220, 10, 150, 150);
        Rectangle Square = new Rectangle(380, 10, 150, 150);

        bool RectangleClicked = false;
        bool SquareClicked = false;
        bool CircleClicked = false;

        int RectangleX = 0;
        int RectangleY = 0;
        int SquareX = 0;
        int SquareY = 0;
        int CircleX = 0;
        int CircleY = 0;

        int X, Y, dX, dY;
        int LastClicked = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Red, Circle);
            e.Graphics.FillRectangle(Brushes.Blue, Square);
            e.Graphics.FillRectangle(Brushes.Yellow, Rectangle);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if ((e.X < Rectangle.X + Rectangle.Width) && (e.X > Rectangle.X))
            {
                if ((e.Y < Rectangle.Y + Rectangle.Width) && (e.Y > Rectangle.Y))
                {
                    RectangleClicked = true;
                    LastClicked = 1;

                    RectangleX = e.X - Rectangle.X;
                    RectangleY = e.Y - Rectangle.Y;
                }
            }

            if ((e.X < Square.X + Square.Width) && (e.X > Square.X))
            {
                if ((e.Y < Square.Y + Square.Width) && (e.Y > Square.Y))
                {
                    SquareClicked = true;
                    LastClicked = 2;

                    SquareX = e.X - Square.X;
                    SquareY = e.Y - Square.Y;
                }
            }

            if ((e.X < Circle.X + Circle.Width) && (e.X > Circle.X))
            {
                if ((e.Y < Circle.Y + Circle.Width) && (e.Y > Circle.Y))
                {
                    CircleClicked = true;
                    LastClicked = 3;

                    CircleX = e.X - Circle.X;
                    CircleY = e.Y - Circle.Y;
                }
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
             RectangleClicked = false;
             SquareClicked = false;
             CircleClicked = false;

            if (LastClicked == 2)
            {
                if ((label2.Location.X < Circle.X + Circle.Width) && (label2.Location.X > Circle.X))
                {
                    if ((label2.Location.Y < Circle.Y + Circle.Height) && (label2.Location.Y > Circle.Y))
                    {
                        X = Circle.X;
                        Y = Circle.Y;
                        dX = CircleX;
                        dY = CircleY;
                        Circle.X = Square.X;
                        Circle.Y = Square.Y;
                        CircleX = SquareX;
                        CircleY = SquareY;

                        Square.X = X;
                        Square.Y = Y;
                        SquareX = dX;
                        SquareY = dY;
                    }
                }
            }

        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (RectangleClicked)
            {
                Rectangle.X = e.X - RectangleX;
                Rectangle.Y = e.Y - RectangleY;
            }
            if (SquareClicked)
            {
                Square.X = e.X - SquareX;
                Square.Y = e.Y - SquareY;
            }
            if (CircleClicked)
            {
                Circle.X = e.X - CircleX;
                Circle.Y = e.Y - CircleY;
            }
            pictureBox1.Invalidate();

            if ((label3.Location.X < Square.X + Square.Width) && (label3.Location.X > Square.X))
            {
                if ((label3.Location.Y < Square.Y + Square.Width) && (label3.Location.Y > Square.Y))
                {
                    label3.Text = "Синий квадрат";
                }
            }

            if ((label3.Location.X < Rectangle.X + Rectangle.Width) && (label3.Location.X > Rectangle.X))
            {
                if ((label3.Location.Y < Rectangle.Y + Rectangle.Width) && (label3.Location.Y > Rectangle.Y))
                {
                    label3.Text = "Желтый прямоугольник";
                }
            }

            if ((label3.Location.X < Circle.X + Circle.Width) && (label3.Location.X > Circle.X))
            {
                if ((label3.Location.Y < Circle.Y + Circle.Width) && (label3.Location.Y > Circle.Y))
                {
                    label3.Text = "Красный круг";
                }
            }

            if ((label2.Location.X < Square.X + Square.Width) && (label2.Location.X > Square.X))
            {
                if ((label2.Location.Y < Square.Y + Square.Width) && (label2.Location.Y > Square.Y))
                {
                    label2.Text = "Квадрат";
                }
            }

            if ((label2.Location.X < Rectangle.X + Rectangle.Width) && (label2.Location.X > Rectangle.X))
            {
                if ((label2.Location.Y < Rectangle.Y + Rectangle.Width) && (label2.Location.Y > Rectangle.Y))
                {
                    label2.Text = "Прямоугольник";
                }
            }

            if ((label2.Location.X < Circle.X + Circle.Width) && (label2.Location.X > Circle.X))
            {
                if ((label2.Location.Y < Circle.Y + Circle.Width) && (label2.Location.Y > Circle.Y))
                {
                    label2.Text = "Круг";
                }
            }

        }



        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
